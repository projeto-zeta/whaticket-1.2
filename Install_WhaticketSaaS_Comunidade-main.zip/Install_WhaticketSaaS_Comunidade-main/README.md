<h1 align="center">Whaticket Baileys Comunidade | Maanabee Criativa</h1>

<div align="center">

[![Maanabee](https://img.shields.io/badge/ead-Maanabee-Yellow)](https://ead.maanabee.com.br/) 
[![License](https://img.shields.io/badge/license-GPL--3.0-orange)](./LICENSE)
[![Nubank](https://img.shields.io/badge/donate-nubank-purple)](https://nubank.com.br/pagar/1j4x3i/qA4jW8n5WR)
[![Suporte](https://img.shields.io/badge/atendimento-online-orange)](https://1378.3cx.cloud/ronanferreira)
[![Agendamento](https://img.shields.io/badge/agendar-suporte-blue)](https://crm.patrulhasolutions.com.br/appointly/appointments_public/form?col=col-md-8+col-md-offset-2)



</div>
  
<div align="center"><img src="https://crm.patrulhasolutions.com.br/uploads/company/b31c6151b72860d92e6eb600b6b9a098.png" style="width: 80% !important;"></div>

## Para Instalação você precisa:

Uma VPS Ubuntu 20.04 (Configuração recomendada: 3 VCPU's + 4 GB RAM)

Subdominio para Frontend

Subdominio para API - backoffice

Email válido para certificação SSL

## SSL

To install the SSL certificate, follow the **[instructions](https://certbot.eff.org/instructions?ws=other&os=ubuntufocal)** below.

## Link p/ Página de Apoio

Acesse: https://ead.maanabee.com.br/mod/forum/discuss.php?d=2#p2

## Vamos instalar?

    cd /home && git clone https://github.com/ronandesign/Install_WhaticketSaaS_Comunidade.git


## Consultoria e contato:

    PATRULHA SOLUTIONS BUSINESS TECHNOLOGY LTDA

    Fone: 14 3333-1488 (WhatsApp)

    Email: contato@patrulhasolutions.com.br

<div align="center">
    <h3>Atendimento online!</h3>
  <a href="https://1378.3cx.cloud/ronanferreira" target="_blank" rel="noopener noreferrer">
    <img src="./public/images/online.png" style="width: 25% !important;">
  </a>
</div>

<div align="center">
    <h3>Agendar atendimento:</h3>
  <a href="https://crm.patrulhasolutions.com.br/appointly/appointments_public/form?col=col-md-8+col-md-offset-2" target="_blank" rel="noopener noreferrer">
    <img src="https://www.spsp.org.br/wp-content/uploads/2019/03/Icone-Agenda-Calendario.png" style="width: 25% !important;">
  </a>
</div></br>

************ LINKS DA COMUNIDADE MAANABEE ************************</br>
 TELEGRAM</br>
Jobs 🇧🇷 | Maanabee 🐝 = https://t.me/JobsMaanabee</br>
Comunidade Maanabee = https://t.me/+Af9heWBPVYkzNmFh</br>
</br>
 WHATSAPP</br>
 *********---***********-------</br>
Comunidade Maanabee no Whats = https://chat.whatsapp.com/GGx3C43wbvwCfnBXzJuM5R</br>
Jobs 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/Ix5u3R0vtG0BJ4ONcGo1Hj</br>
*********---***********-------</br>
</br>
Jet Engine 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/GKMLyIg7K28LsgfyS5lgk9</br>
Evolution-API 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/JbSH0P5viaKEFfSccZTAKC</br>
Chatwoot 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/JdYxODQVtXmBDH3s7Z4d9B</br>
Elementor 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/JHCD2AMTu15JFf81lwxeM8</br>
WordPress 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/I654aDXuViLKuzKfk45MDL</br>
Woocommerce 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/GFYJZi5WMgWHLlNr7A5hDD</br>
Whaticket 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/BcLNrq9CXi64i0WVZnmp58</br>
Press Ticket 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/IwxvFOFb4no0L1oMnAJrWN</br>
n8n 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/IwxvFOFb4no0L1oMnAJrWN</br>
Baileys 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/BA6J0ddLmzu6JWVkrRFZ06</br>
AppSmith 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/I6Q0TAijxEV87AAaEbc0Yr</br>
Typebot 🇧🇷 | Maanabee 🐝 = https://chat.whatsapp.com/KKLtSuXe8kV07YtTyqwH2L</br>
</br>
****************************************************</br>


## Se o conteúdo te ajudou ajude este projeto:
(Nos ajude a trazer novos conteúdos todos os dias!)

<div align="center">
    <h3>Ajude com qualquer valor</h3>
  <a href="https://nubank.com.br/pagar/1j4x3i/qA4jW8n5WR" target="_blank" rel="noopener noreferrer">
    <img src="./public/images/nubank.jpeg" style="width: 50% !important;">
  </a>
</div>

Copia e cola:

    00020126580014BR.GOV.BCB.PIX0136c5f2b8ea-6e17-4768-990a-8798cded1a515204000053039865802BR5925Ronan Emmanuel de Paula F6009SAO PAULO61080540900062250521jA1yivHCQ3yFaxQ1j4x3i6304C676

